// Impostare a true quando il programma è finito, per mostrare la schermata di login
var LOGIN_ATTIVO = false;
if (LOGIN_ATTIVO) { var l = document.getElementById('login'); l.classList.add('on'); l.setAttribute('aria-hidden','false'); }

var I = {
  home:'<svg viewBox="0 0 24 24"><path d="M3 11l9-8 9 8M5 10v10h14V10"/></svg>',
  users:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6M16 4.8a3.5 3.5 0 010 6.4M18 14.4c2 .7 3.5 2.5 3.5 5.6"/></svg>',
  plan:'<svg viewBox="0 0 24 24"><path d="M2 9v6M5 6v12M19 6v12M22 9v6M5 12h14"/></svg>',
  cal:'<svg viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
  ev:'<svg viewBox="0 0 24 24"><path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z"/></svg>'
};
var S = [
  {id:'utenti',t:'Utenti',d:'Iscritti, anagrafica e abbonamenti',i:I.users,c:'var(--c1)',s:'Gestisci iscritti'},
  {id:'schede',t:'Schede allenamento',d:'Crea e assegna programmi di allenamento',i:I.plan,c:'var(--c2)',s:'Gestisci schede'},
  {id:'calendario',t:'Calendario',d:'Corsi, appuntamenti e prenotazioni',i:I.cal,c:'var(--c3)',s:'Apri calendario'},
  {id:'eventi',t:'Eventi',d:'Open day, workshop e iniziative',i:I.ev,c:'var(--c4)',s:'Gestisci eventi'}
];
var cur = 'home';
function render(){
  var m = document.getElementById('main'), h = '';
  if (cur === 'home') {
    h = '<h2>Benvenuto</h2><p class="sub">Scegli una sezione per iniziare.</p><div class="grid">' +
      S.map(function(x){return '<button class="card" style="--col:'+x.c+'" data-go="'+x.id+'"><div class="ic">'+x.i+'</div><h3>'+x.t+'</h3><p>'+x.d+'</p><span class="stat">'+x.s+' →</span></button>'}).join('') + '</div>';
  } else {
    var x = S.filter(function(y){return y.id===cur})[0];
    h = '<button class="back" data-go="home">← Home</button><h2>'+x.t+'</h2><p class="sub">'+x.d+'</p><div class="panel">Sezione in sviluppo.</div>';
  }
  m.innerHTML = h;
  if (cur === 'utenti') renderUtenti();
  if (cur === 'schede') renderSchede();
  var items = [{id:'home',t:'Home',i:I.home}].concat(S.map(function(x){return {id:x.id,t:x.id==='schede'?'Schede':x.t,i:x.i}}));
  document.getElementById('tabbar').innerHTML = items.map(function(x){return '<button class="tab" data-go="'+x.id+'"'+(x.id===cur?' aria-current="true"':'')+'>'+x.i+'<span>'+x.t+'</span></button>'}).join('');
  document.getElementById('side').innerHTML = items.map(function(x){var f=x.id==='schede'?'Schede allenamento':x.t;return '<button data-go="'+x.id+'"'+(x.id===cur?' aria-current="true"':'')+'>'+x.i+'<span>'+f+'</span></button>'}).join('');
}
document.addEventListener('click', function(e){
  var b = e.target.closest('[data-go]'); if (b) { cur = b.getAttribute('data-go'); render(); window.scrollTo(0,0); }
});
function setView(v){
  document.getElementById('stage').className = 'stage ' + v;
}
var CARICA_DATI_DEMO = false; // metti true per precaricare utenti e schede di esempio al primo avvio
function newId(p){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function showNotice(t){var n=document.createElement('div');n.className='notice';n.setAttribute('role','alert');n.textContent=t;var h=document.querySelector('header');h.parentNode.insertBefore(n,h.nextSibling)}
// Archivio nel browser (IndexedDB): i dati restano su questo dispositivo, senza server
var Store=(function(){
  var db=null;
  function open(){return new Promise(function(res,rej){
    if(!window.indexedDB){rej(new Error('noidb'));return}
    var r=indexedDB.open('speaking',1);
    r.onupgradeneeded=function(){['utenti','schede'].forEach(function(n){if(!r.result.objectStoreNames.contains(n))r.result.createObjectStore(n,{keyPath:'id'})})};
    r.onsuccess=function(){res(r.result)};
    r.onerror=function(){rej(r.error)};
  })}
  function tx(n,mode,fn){return new Promise(function(res,rej){
    var t=db.transaction(n,mode),q=fn(t.objectStore(n));
    t.oncomplete=function(){res(q&&q.result)};
    t.onerror=t.onabort=function(){rej(t.error)};
  })}
  return {
    load:function(){
      return open().then(function(d){
        db=d;
        if(navigator.storage&&navigator.storage.persist)navigator.storage.persist();
        return Promise.all([tx('utenti','readonly',function(s){return s.getAll()}),tx('schede','readonly',function(s){return s.getAll()})]);
      }).then(function(r){
        U=r[0]||[];SCH=r[1]||[];
        if(CARICA_DATI_DEMO&&!U.length&&!SCH.length){
          U=DEMO_U.slice();SCH=DEMO_SCH.slice();
          return Promise.all(U.map(function(o){return Store.put('utenti',o)}).concat(SCH.map(function(o){return Store.put('schede',o)})));
        }
      }).catch(function(){
        db=null;
        showNotice('Archivio del browser non disponibile (navigazione privata?): i dati non verranno salvati.');
      });
    },
    put:function(n,o){return db?tx(n,'readwrite',function(s){return s.put(o)}):Promise.resolve()},
    del:function(n,id){return db?tx(n,'readwrite',function(s){return s.delete(id)}):Promise.resolve()}
  };
})();
var DEMO_U = [
 {id:1,n:'Marco',c:'Rossi',d:'1985-03-12',cf:'RSSMRC85C12A462X',t:'333 1234567',e:'marco.rossi@email.it',ci:'Ascoli Piceno'},
 {id:2,n:'Giulia',c:'Bianchi',d:'1992-07-25',cf:'BNCGLI92L65A462K',t:'347 7654321',e:'giulia.bianchi@email.it',ci:'San Benedetto'},
 {id:3,n:'Luca',c:'Ferrari',d:'1978-11-03',cf:'FRRLCU78S03A462P',t:'320 1122334',e:'luca.ferrari@email.it',ci:'Ascoli Piceno'}
];
var U = [];
var uq = '', dm = false, sel = {}, draft = {front:null,back:null};
var dbCol = null, caps = {sample:null,assets:null,down:null};
var sState = 'local';
function sampleMsg(){
  if(sState==='ok') return 'Carica fronte e/o retro per compilare i campi in automatico.';
  if(sState==='local') return 'Carica fronte e/o retro per compilare i campi in automatico (la prima lettura scarica il modello di riconoscimento: serve internet).';
  if(sState==='pending') return 'Verifica della lettura automatica in corso…';
  if(sState==='none') return 'Lettura automatica non disponibile: compila i campi a mano.';
  return 'Lettura automatica non disponibile per questo profilo o in questa vista: compila i campi a mano.';
}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function fdate(s){if(!s)return '—';var p=s.split('-');return p.length===3?p[2]+'/'+p[1]+'/'+p[0]:s}
function filtered(){
  var q=uq.toLowerCase().trim();
  return U.filter(function(u){return !q||[u.n,u.c,u.cf,u.t,u.e,u.ci].join(' ').toLowerCase().indexOf(q)>-1})
   .sort(function(a,b){return (a.c+a.n).localeCompare(b.c+b.n)});
}
function renderUtenti(){
  document.getElementById('main').innerHTML =
   '<div class="uh"><div><h2>Utenti</h2><p class="sub" id="ucount"></p></div><div class="uact">'+
   '<button class="ab pri" data-act="add" aria-label="Crea utente"><span class="i">+</span><span class="t">Crea</span></button>'+
   '<button class="ab" id="bdel" data-act="del" aria-label="Elimina utenti"><span class="i">−</span><span class="t">Elimina</span></button></div></div>'+
   '<input class="search" id="usearch" type="search" placeholder="Cerca per nome, codice fiscale, email…" value="'+esc(uq)+'">'+
   '<div id="dbar"></div><div id="ulist"></div>';
  document.getElementById('usearch').addEventListener('input',function(e){uq=e.target.value;listUtenti()});
  listUtenti();
}
function hasDoc(u){return !!(u.frontId||u.backId||u.frontBlob||u.backBlob)}
function listUtenti(){
  var L = filtered(), n = Object.keys(sel).length;
  document.getElementById('ucount').textContent = L.length + (L.length===1?' utente':' utenti');
  document.getElementById('dbar').innerHTML = dm ? '<div class="dbar"><span>Seleziona gli utenti da eliminare ('+n+')</span><div><button data-act="cancel">Annulla</button><button class="danger" data-act="confirmdel"'+(n?'':' disabled')+'>Elimina</button></div></div>' : '';
  document.getElementById('bdel').classList.toggle('danger', dm);
  var h = L.length ? '<div class="uhead"><span>Nominativo</span><span>Nascita</span><span>Codice fiscale</span><span>Telefono</span><span>Email</span><span>Città</span></div>' : '<div class="empty">Nessun utente trovato.</div>';
  h += L.map(function(u){
    return '<div class="urow'+(sel[u.id]?' sel':'')+'" data-row="'+esc(u.id)+'">'+(dm?'<input type="checkbox"'+(sel[u.id]?' checked':'')+' aria-label="Seleziona">':'')+
    '<div class="av">'+esc((u.n[0]||'')+(u.c[0]||'')).toUpperCase()+'</div><div class="cells"><b>'+esc(u.n+' '+u.c)+(hasDoc(u)?' <i class="dc">documento</i>':'')+'</b><span>Nato il '+fdate(u.d)+'</span><span>'+esc(u.cf||'—')+'</span><span>'+esc(u.t||'—')+'</span><span>'+esc(u.e||'—')+'</span><span>'+esc(u.ci||'—')+'</span></div></div>';
  }).join('');
  document.getElementById('ulist').innerHTML = h;
}
function modal(html){var m=document.getElementById('modal');if(!m){m=document.createElement('div');m.id='modal';m.className='modal';document.body.appendChild(m)}m.innerHTML='<div class="mbox">'+html+'</div>'}
function closeModal(){var m=document.getElementById('modal');if(m)m.remove()}
function st(id,t){var e=document.getElementById(id);if(e)e.textContent=t}
var FIELDS=[['n','Nome'],['c','Cognome'],['d','Data di nascita','date'],['cf','Codice fiscale'],['t','Telefono','tel'],['e','Email','email'],['ci','Città di residenza'],['dn','N. documento'],['ds','Scadenza documento','date']];
function dropHtml(side,label){
  return '<div class="drop">'+label+'<div class="btns"><label class="pb cam">📷 Scatta foto<input type="file" accept="image/*" capture="environment" data-side="'+side+'" hidden></label>'+
   '<label class="pb">Scegli file<input type="file" accept="image/*" data-side="'+side+'" hidden></label></div><img id="pv_'+side+'" alt="Anteprima '+label.toLowerCase()+'"></div>';
}
function addForm(){
  draft={front:null,back:null};
  modal('<h3>Nuovo utente</h3><div class="idbox"><b>Documento d’identità</b>'+
   '<div class="idrow">'+dropHtml('front','Fronte')+dropHtml('back','Retro')+'</div>'+
   '<button id="bread" data-act="read" disabled>Leggi dati dal documento</button><div class="status" id="rstat">'+sampleMsg()+'</div><details id="rawd" hidden><summary>Mostra testo letto</summary><pre id="rawt"></pre></details></div>'+
   FIELDS.map(function(x){return '<label>'+x[1]+(x[0]==='n'||x[0]==='c'?' *':'')+'<input id="f_'+x[0]+'" type="'+(x[2]||'text')+'"></label>'}).join('')+
   '<div class="status" id="sstat"></div><div class="mrow"><button data-act="mclose">Annulla</button><button class="pri" id="bsave" data-act="msave">Salva</button></div>');
}
function shrink(file){return new Promise(function(res,rej){
  var im=new Image(),u=URL.createObjectURL(file);
  im.onload=function(){var s=Math.min(1,1600/Math.max(im.width,im.height)),cv=document.createElement('canvas');cv.width=Math.round(im.width*s);cv.height=Math.round(im.height*s);cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);URL.revokeObjectURL(u);cv.toBlob(function(b){b?res(b):rej()},'image/jpeg',0.85)};
  im.onerror=function(){rej()};im.src=u})}
async function pickFile(side,file){
  try{
    var b=await shrink(file); draft[side]=b;
    var pv=document.getElementById('pv_'+side); pv.src=URL.createObjectURL(b); pv.style.display='block';
    var br=document.getElementById('bread'); if(br) br.disabled=!(caps.sample||sState==='local');
  }catch(e){ st('rstat','Immagine non valida: scegli una foto (JPG o PNG).') }
}
// Lettura documento direttamente nel browser (Tesseract.js), senza server e senza API
var DIG={O:'0',Q:'0',D:'0',I:'1',L:'1',Z:'2',S:'5',B:'8',G:'6'}, LET={'0':'O','1':'I','2':'Z','5':'S','8':'B','6':'G'};
function dfix(s){return s.replace(/[A-Z]/g,function(c){return DIG[c]||c})}
function lfix(s){return s.replace(/[0-9]/g,function(c){return LET[c]||c})}
function ymd(s,kind){
  if(!/^\d{6}$/.test(s))return '';
  var y=+s.slice(0,2),m=+s.slice(2,4),d=+s.slice(4,6); if(m<1||m>12||d<1||d>31)return '';
  var cy=new Date().getFullYear()%100, Y=kind==='b'?(y>cy?1900:2000)+y:2000+y;
  return Y+'-'+('0'+m).slice(-2)+'-'+('0'+d).slice(-2);
}
function tcase(s){return s.toLowerCase().replace(/(^|[\s'’-])([a-zà-ÿ])/g,function(_,a,b){return a+b.toUpperCase()})}
function mrzCheck(s){var w=[7,3,1],t=0;for(var i=0;i<s.length;i++){var c=s.charAt(i),v=c==='<'?0:/\d/.test(c)?+c:c.charCodeAt(0)-55;t+=v*w[i%3]}return t%10}
function parseMRZ(t){
  var L=String(t).toUpperCase().split(/\n/).map(function(x){return x.replace(/[^A-Z0-9<]/g,'')}).filter(function(x){return x.length>=24});
  var l1,l2,l3;
  L.forEach(function(x){
    x=(x+'<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<').slice(0,30);
    var is2=/^\d{6}\d[MF<]\d{6}\d/.test(dfix(x.slice(0,7))+x.charAt(7)+dfix(x.slice(8,15)));
    var is3=x.indexOf('<<')>0&&/^[A-Z<]+$/.test(x);
    if(is2){if(!l2)l2=x}else if(is3){if(!l3)l3=x}else if(/^[ICA][A-Z<]/.test(x)&&/\d/.test(x.slice(5,14))){if(!l1)l1=x}
  });
  var o={};
  // date e numero documento solo se il carattere di controllo della riga torna
  if(l2){
    var b=dfix(l2.slice(0,6)); if(mrzCheck(b)===+dfix(l2.charAt(6))) o.data_nascita=ymd(b,'b');
    var e=dfix(l2.slice(8,14)); if(mrzCheck(e)===+dfix(l2.charAt(14))) o.scadenza=ymd(e,'e');
  }
  if(l3){var p=l3.split('<<'),c=tcase(p[0].replace(/[<0-9]/g,' ').trim()),n=tcase((p[1]||'').replace(/[<0-9]/g,' ').trim());
    if(/^[A-Za-zÀ-ÿ' ]{2,}$/.test(c))o.cognome=c; if(/^[A-Za-zÀ-ÿ' ]{2,}$/.test(n))o.nome=n}
  if(l1){var dn=l1.slice(5,14),ck=+dfix(l1.charAt(14));if(mrzCheck(dn)===ck||mrzCheck(dfix(dn))===ck)o.numero_documento=dn.replace(/</g,'')}
  return o;
}
var ODD=[1,0,5,7,9,13,15,17,19,21,2,4,18,20,11,3,6,8,12,14,16,10,22,25,24,23];
function cfCheck(c){var t=0;for(var i=0;i<15;i++){var ch=c.charAt(i),v=/\d/.test(ch)?+ch:ch.charCodeAt(0)-65;t+=i%2===0?ODD[v]:v}return String.fromCharCode(65+t%26)===c.charAt(15)}
function findCF(text){
  var cands=[];
  String(text).toUpperCase().split(/\n/).forEach(function(line){
    var s=line.replace(/[^A-Z0-9]/g,'');
    for(var i=0;i+16<=s.length;i++){
      var w=s.slice(i,i+16),f=lfix(w.slice(0,6))+dfix(w.slice(6,8))+lfix(w.charAt(8))+dfix(w.slice(9,11))+lfix(w.charAt(11))+dfix(w.slice(12,15))+lfix(w.charAt(15));
      if(/^[A-Z]{6}\d{2}[A-EHLMPRST]\d{2}[A-Z]\d{3}[A-Z]$/.test(f))cands.push(f);
    }
  });
  var ok=cands.filter(cfCheck);
  return ok.length?{cf:ok[0],ok:true}:(cands.length?{cf:cands[0],ok:false}:null);
}
var LABEL=/cognome|surname|nome|name|sesso|sex|nascita|birth|statura|height|cittadin|national|scadenza|expir|emission|rilascio|issue|residen|comune|luogo|data|date|codice|fiscal|repubblica|ministero|identit|carta|italian|firma|signature/i;
function allDates(t){
  var out=[],re=/(\d{1,2})\s*[\/\.\-]\s*(\d{1,2})\s*[\/\.\-]\s*(\d{4})/g,m,cy=new Date().getFullYear();
  while((m=re.exec(t))){var d=+m[1],mo=+m[2],y=+m[3];if(d>=1&&d<=31&&mo>=1&&mo<=12&&y>=1900&&y<=cy+12){var iso=y+'-'+('0'+mo).slice(-2)+'-'+('0'+d).slice(-2);if(out.indexOf(iso)<0)out.push(iso)}}
  return out.sort();
}
function parseFront(t){
  var lines=String(t).split(/\n/).map(function(x){return x.trim()}).filter(Boolean),o={};
  function letters(s){return s.replace(/[^A-Za-zÀ-ÿ' ]/g,' ').replace(/\s+/g,' ').trim()}
  function find(re){for(var i=0;i<lines.length;i++)if(re.test(lines[i]))return i;return -1}
  var used=-1;
  function value(i){for(var k=Math.max(i+1,used+1);k<=i+4&&k<lines.length;k++){var v=letters(lines[k]);if(v.length>=2&&v.length<=30&&!LABEL.test(v)){used=k;return tcase(v)}}return ''}
  var i=find(/^\W*cognome/i); if(i>-1){var c=value(i);if(c)o.cognome=c}
  i=find(/^\W*nome\b/i); if(i>-1){var n=value(i);if(n)o.nome=n}
  var ds=allDates(t), near=function(re){var j=find(re);return j>-1?allDates(lines.slice(j,j+3).join(' ')):[]};
  var nb=near(/nascita|birth/i), ne=near(/scadenza|expir/i);
  if(ds.length>=2){
    o.data_nascita=nb.length?nb[0]:ds[0];
    var mx=ds[ds.length-1];
    // la scadenza è la data più recente; con sole due date serve l'etichetta per distinguerla dall'emissione
    if(ds.length>=3||ne.indexOf(mx)>-1)o.scadenza=mx;
  }else if(ds.length===1){
    if(ne.length)o.scadenza=ds[0];else if(nb.length)o.data_nascita=ds[0];
  }
  i=find(/residenza|residence/i); if(i>-1){var r=letters((lines[i+1]||'').split(/[(,]/)[0]); if(r.length>2&&!LABEL.test(r))o.residenza=tcase(r)}
  var cf=findCF(t); if(cf){o.codice_fiscale=cf.cf;if(!cf.ok)o._cfWarn=1}
  var dn=String(t).toUpperCase().match(/\b[A-Z]{2}\s?\d{5}\s?[A-Z]{2}\b/); if(dn)o.numero_documento=dn[0].replace(/\s/g,'');
  return o;
}
var TESS_BASE=new URL('vendor/tesseract/',document.baseURI).href, TESS_LOCAL=false;
function addScript(src){return new Promise(function(ok,ko){var sc=document.createElement('script');sc.src=src;sc.onload=ok;sc.onerror=function(){sc.remove();ko(new Error('net'))};document.head.appendChild(sc)})}
function loadTess(){
  if(window.Tesseract)return Promise.resolve(window.Tesseract);
  return addScript(TESS_BASE+'tesseract.min.js').then(function(){TESS_LOCAL=true;return window.Tesseract})
   .catch(function(){return addScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js').then(function(){return window.Tesseract})});
}
// ingrandisce, passa in grigio, aumenta il contrasto; con y0 taglia la parte bassa; con bin rende bianco/nero
function prep(blob,o){return new Promise(function(ok,ko){
  var im=new Image(),u=URL.createObjectURL(blob);
  im.onerror=function(){ko(new Error('img'))};
  im.onload=function(){
    var sy=Math.round(im.height*(o.y0||0)),sh=im.height-sy,s=(o.w||im.width)/im.width,cw=Math.round(im.width*s),ch=Math.round(sh*s);
    var cv=document.createElement('canvas');cv.width=cw;cv.height=ch;var cx=cv.getContext('2d');
    cx.drawImage(im,0,sy,im.width,sh,0,0,cw,ch);
    var d=cx.getImageData(0,0,cw,ch),p=d.data,hist=new Array(256).fill(0),i,g,tot=cw*ch,acc=0,lo=0,hi=255;
    for(i=0;i<p.length;i+=4){g=Math.round(.299*p[i]+.587*p[i+1]+.114*p[i+2]);p[i]=g;hist[g]++}
    for(i=0;i<256;i++){acc+=hist[i];if(acc>=tot*.02){lo=i;break}}
    acc=0;for(i=255;i>=0;i--){acc+=hist[i];if(acc>=tot*.02){hi=i;break}}
    var rng=Math.max(1,hi-lo),h2=new Array(256).fill(0);
    for(i=0;i<p.length;i+=4){g=Math.max(0,Math.min(255,Math.round((p[i]-lo)*255/rng)));p[i]=g;h2[g]++}
    var tr=128;
    if(o.bin){var sum=0,sB=0,wB=0,mx=0;for(i=0;i<256;i++)sum+=i*h2[i];for(i=0;i<256;i++){wB+=h2[i];if(!wB)continue;var wF=tot-wB;if(!wF)break;sB+=i*h2[i];var mB=sB/wB,mF=(sum-sB)/wF,v=wB*wF*(mB-mF)*(mB-mF);if(v>mx){mx=v;tr=i}}}
    for(i=0;i<p.length;i+=4){g=p[i];if(o.bin)g=g>tr?255:0;p[i]=p[i+1]=p[i+2]=g}
    cx.putImageData(d,0,0);
    cv.toBlob(function(b){URL.revokeObjectURL(u);b?ok(b):ko(new Error('img'))},'image/png');
  };
  im.src=u;
})}
async function ocr(blob,lang,params,onp){
  var T=await loadTess();
  var opts={logger:function(m){if(m.status==='recognizing text'&&onp)onp(m.progress)}};
  if(TESS_LOCAL){opts.workerPath=TESS_BASE+'worker.min.js';opts.corePath=TESS_BASE;opts.langPath=TESS_BASE+'lang'}
  var w=await T.createWorker(lang,1,opts);
  try{ if(params)await w.setParameters(params); var r=await w.recognize(blob); return r.data.text||'' }
  finally{ await w.terminate() }
}
function showRaw(txt){var d=document.getElementById('rawd'),p=document.getElementById('rawt');if(d&&p){p.textContent=txt;d.hidden=false}}
async function localRead(){
  var prog=function(p){st('rstat','Lettura in corso… '+Math.round(p*100)+'%')}, texts=[], mrzTexts=[];
  for(var s of ['front','back']){ if(draft[s]) texts.push(await ocr(await prep(draft[s],{w:2000}),'ita',null,prog)) }
  // riga di caratteri in basso (MRZ): provo in grigio e in bianco/nero e tengo il risultato più completo
  var mrz={}, src=draft.back||draft.front;
  for(var bin of [false,true]){
    var tx=await ocr(await prep(src,{y0:.55,w:2400,bin:bin}),'eng',{tessedit_char_whitelist:'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<',tessedit_pageseg_mode:'6'},prog);
    mrzTexts.push(tx); var m=parseMRZ(tx); if(Object.keys(m).length>Object.keys(mrz).length)mrz=m;
  }
  var fr=parseFront(texts.join('\n')), out={};
  [fr,mrz].forEach(function(o){Object.keys(o).forEach(function(k){if(o[k])out[k]=o[k]})});
  showRaw('--- TESTO ---\n'+texts.join('\n--- altra immagine ---\n')+'\n--- MRZ ---\n'+mrzTexts.join('\n--- altro tentativo ---\n'));
  return out;
}
async function readDoc(){
  var imgs=[draft.front,draft.back].filter(Boolean); if(!imgs.length||!(caps.sample||sState==='local')) return;
  var b=document.getElementById('bread'); b.disabled=true; st('rstat','Lettura in corso…');
  try{
    var r=caps.sample ? await caps.sample.json('Le immagini allegate sono il fronte e/o il retro di un documento d’identità (in quest’ordine: fronte, poi retro se presente). Estrai i dati e rispondi solo con un oggetto JSON con queste chiavi: nome, cognome, data_nascita (formato AAAA-MM-GG), codice_fiscale, residenza (solo città), numero_documento, scadenza (formato AAAA-MM-GG). Usa una stringa vuota per ciò che non è leggibile e non inventare nulla.',{images:imgs}) : await localRead();
    var m={n:r.nome,c:r.cognome,d:r.data_nascita,cf:r.codice_fiscale,ci:r.residenza,dn:r.numero_documento,ds:r.scadenza};
    var fl=0;Object.keys(m).forEach(function(k){var el=document.getElementById('f_'+k);if(el&&m[k]){el.value=String(m[k]).trim();fl++}});
    st('rstat',fl?'Dati compilati ('+fl+' campi): controllali prima di salvare.'+(r._cfWarn?' Codice fiscale da verificare.':(!r.codice_fiscale?' Codice fiscale non trovato.':'')):'Non sono riuscito a leggere il documento: prova con una foto più nitida o compila a mano.');
  }catch(e){ st('rstat',e&&e.message==='net'?'Impossibile scaricare il modello di lettura: serve una connessione internet.':'Lettura non riuscita: compila i campi a mano.') }
  b.disabled=false;
}
async function saveUser(){
  var o={}; FIELDS.forEach(function(x){o[x[0]]=document.getElementById('f_'+x[0]).value.trim()});
  if(!o.n||!o.c){document.getElementById(o.n?'f_c':'f_n').focus();return}
  o.cf=o.cf.toUpperCase();
  var has=draft.front||draft.back;
  var b=document.getElementById('bsave'); b.disabled=true; b.textContent='Salvataggio…';
  try{
    for(var side of ['front','back']){ if(!draft[side])continue;
      if(caps.assets){var a=await caps.assets.upload(draft[side]);o[side+'Id']=a.id}
      else{o[side+'Blob']=draft[side]} }
    o.id=newId('u');await Store.put('utenti',o);U.unshift(o);listUtenti();
    closeModal();
  }catch(e){b.disabled=false;b.textContent='Salva';st('sstat','Salvataggio non riuscito. Riprova.')}
}
function find(id){return U.filter(function(u){return String(u.id)===String(id)})[0]}
function openUser(id){
  var u=find(id); if(!u)return;
  var rows=[['Nome',u.n+' '+u.c],['Data di nascita',fdate(u.d)],['Codice fiscale',u.cf],['Telefono',u.t],['Email',u.e],['Città',u.ci],['N. documento',u.dn],['Scadenza documento',fdate(u.ds)]];
  var btn=function(s,l){return (u[s+'Id']||u[s+'Blob'])?'<button data-act="dl" data-id="'+esc(u.id)+'" data-side="'+s+'">Scarica '+l+'</button>':''};
  var docs=btn('front','fronte')+btn('back','retro');
  modal('<h3>'+esc(u.n+' '+u.c)+'</h3><dl class="det">'+rows.map(function(r){return '<dt>'+r[0]+'</dt><dd>'+esc(r[1]||'—')+'</dd>'}).join('')+'</dl>'+
   '<div class="idbox"><b>Documento d’identità</b>'+(docs?'<div class="idrow">'+docs+'</div>':'<div class="status">Nessun documento salvato.</div>')+'<div class="status" id="dstat"></div></div>'+
   '<div class="mrow"><button data-act="mclose">Chiudi</button></div>');
}
async function dl(id,side){
  var u=find(id); if(!u)return;
  try{
    var blob=u[side+'Blob']; if(!blob){var r=await fetch('/_blob/'+u[side+'Id']);blob=await r.blob()}
    var name=(u.c+'_'+u.n+'_'+(side==='front'?'fronte':'retro')+'.jpg').replace(/\s+/g,'_');
    if(caps.down){await caps.down.save({filename:name,data:blob})}
    else{var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove()}
  }catch(e){ if(e&&e.code==='declined')return; st('dstat','Download non riuscito. Riprova.') }
}
async function doDelete(){
  var ids=Object.keys(sel);
  for(var i=0;i<ids.length;i++){
    var u=find(ids[i]); if(!u)continue;
    try{await Store.del('utenti',u.id)}catch(e){}
    await dropSchedeOf(u.id);
    if(caps.assets){for(var s of ['frontId','backId']){if(u[s]){try{await caps.assets.delete(u[s])}catch(e){}}}}
  }
  U=U.filter(function(u){return !sel[u.id]});
  sel={};dm=false;closeModal();listUtenti();
}
document.addEventListener('change',function(e){var t=e.target;if(t.getAttribute&&t.getAttribute('data-side')&&t.files&&t.files[0]){var f=t.files[0];pickFile(t.getAttribute('data-side'),f);t.value=''}});
document.addEventListener('click',function(e){
  var a=e.target.closest('[data-act]'),r=e.target.closest('[data-row]');
  if(a){var k=a.getAttribute('data-act');
    if(k==='add')addForm();
    else if(k==='mclose')closeModal();
    else if(k==='read')readDoc();
    else if(k==='msave')saveUser();
    else if(k==='dl')dl(a.getAttribute('data-id'),a.getAttribute('data-side'));
    else if(k==='del'){dm=!dm;sel={};listUtenti()}
    else if(k==='cancel'){dm=false;sel={};listUtenti()}
    else if(k==='confirmdel'){var n=Object.keys(sel).length;if(!n)return;modal('<h3>Elimina utenti</h3><p>Vuoi eliminare '+n+(n===1?' utente selezionato':' utenti selezionati')+', compresi i documenti salvati? L’operazione non si può annullare.</p><div class="mrow"><button data-act="mclose">Annulla</button><button class="danger" data-act="dodel">Elimina</button></div>')}
    else if(k==='dodel')doDelete();
    return}
  if(r){var id=r.getAttribute('data-row');if(dm){if(sel[id])delete sel[id];else sel[id]=1;listUtenti()}else openUser(id)}
});
// ---- Schede allenamento (struttura provvisoria: nome, data, note, elenco esercizi con serie, ripetizioni e carico) ----
var EXLIST=['Panca piana','Squat','Stacco da terra','Military press','Rematore con bilanciere','Trazioni','Lat machine','Leg press','Curl con bilanciere','Pushdown ai cavi','Affondi','Plank'];
function mkS(id,u,nome,data,es){return {id:'d'+id,uid:String(u),nome:nome,data:data,note:'',es:es.map(function(x){return {n:x[0],s:x[1],r:x[2],k:x[3],g:x[4]}})}}
var DEMO_SCH=[
 mkS(1,1,'Forza base','2026-05-10',[['Panca piana',3,8,60],['Squat',3,8,80],['Rematore con bilanciere',3,10,50]]),
 mkS(2,1,'Forza base 2','2026-07-12',[['Panca piana',3,8,65],['Squat',3,8,87.5],['Rematore con bilanciere',3,10,55]]),
 mkS(3,1,'Ipertrofia','2026-09-14',[['Panca piana',4,8,70],['Squat',4,8,92.5],['Rematore con bilanciere',4,10,60]]),
 mkS(4,1,'Ipertrofia 2','2026-11-02',[['Panca piana',4,8,72.5,1],['Rematore con bilanciere',4,10,62.5,1],['Squat',4,8,97.5]])
];
var SCH=[];
var dbSch=null, sq='', suid=null, sdm=false, ssel={}, trend=[], eq='';
var TCOL=['var(--c1)','var(--c2)','var(--c3)','var(--c4)'];
function fnum(v){return String(v==null?'':v).replace('.',',')}
function ekey(n){return String(n||'').trim().toLowerCase()}
function schedeOf(u){return SCH.filter(function(x){return String(x.uid)===String(u)}).sort(function(a,b){return b.data.localeCompare(a.data)})}
function findS(id){return SCH.filter(function(x){return String(x.id)===String(id)})[0]}
function exNames(u){var m={};schedeOf(u).forEach(function(sc){sc.es.forEach(function(e){var k=ekey(e.n);if(k&&!m[k])m[k]=e.n})});return m}
function renderSchede(){
  var m=document.getElementById('main');
  if(!suid){
    m.innerHTML='<h2>Schede allenamento</h2><p class="sub" id="sucount"></p><input class="search" id="ssearch" type="search" placeholder="Cerca utente…" value="'+esc(sq)+'"><div id="sulist"></div>';
    listSU();return;
  }
  var u=find(suid); if(!u){suid=null;renderSchede();return}
  m.innerHTML='<button class="back" data-act="sback">← Utenti</button><div class="uh"><div><h2>'+esc(u.n+' '+u.c)+'</h2><p class="sub" id="sccount"></p></div><div class="uact">'+
   '<button class="ab pri" data-act="sadd" aria-label="Crea scheda"><span class="i">+</span><span class="t">Crea</span></button>'+
   '<button class="ab" id="sbdel" data-act="sdel" aria-label="Elimina schede"><span class="i">−</span><span class="t">Elimina</span></button></div></div>'+
   '<div id="sdbar"></div><div id="slist"></div>'+
   '<div class="trend"><h3>Andamento esercizi</h3><input class="search" id="esearch" type="search" placeholder="Cerca un esercizio…" value="'+esc(eq)+'" style="margin-bottom:8px"><div class="chips" id="echips"></div><div id="echart"></div></div>';
  listSchede();drawTrend();
}
function listSU(){
  var q=sq.toLowerCase().trim(),L=U.filter(function(u){return !q||(u.n+' '+u.c).toLowerCase().indexOf(q)>-1}).sort(function(a,b){return (a.c+a.n).localeCompare(b.c+b.n)});
  document.getElementById('sucount').textContent=L.length+(L.length===1?' utente':' utenti');
  document.getElementById('sulist').innerHTML=L.length?L.map(function(u){var sc=schedeOf(u.id);
    return '<div class="urow" data-su="'+esc(u.id)+'" style="cursor:pointer"><div class="av">'+esc((u.n[0]||'')+(u.c[0]||'')).toUpperCase()+'</div><div class="cells two"><b>'+esc(u.n+' '+u.c)+'</b><span>'+(sc.length?sc.length+(sc.length===1?' scheda':' schede')+' · ultima del '+fdate(sc[0].data):'Nessuna scheda')+'</span></div></div>'}).join(''):'<div class="empty">Nessun utente. Aggiungili dalla sezione Utenti.</div>';
}
function listSchede(){
  if(!find(suid)||!document.getElementById('slist'))return;
  var L=schedeOf(suid),n=Object.keys(ssel).length;
  document.getElementById('sccount').textContent=L.length+(L.length===1?' scheda':' schede');
  document.getElementById('sdbar').innerHTML=sdm?'<div class="dbar"><span>Seleziona le schede da eliminare ('+n+')</span><div><button data-act="scancel">Annulla</button><button class="danger" data-act="sconfirm"'+(n?'':' disabled')+'>Elimina</button></div></div>':'';
  document.getElementById('sbdel').classList.toggle('danger',sdm);
  document.getElementById('slist').innerHTML=L.length?L.map(function(x,i){
    return '<div class="urow'+(ssel[x.id]?' sel':'')+'" data-srow="'+esc(x.id)+'" style="cursor:pointer">'+(sdm?'<input type="checkbox"'+(ssel[x.id]?' checked':'')+' aria-label="Seleziona">':'')+
    '<div class="cells two"><b>'+esc(x.nome)+(i===0?' <i class="dc">attuale</i>':'')+'</b><span>'+fdate(x.data)+' · '+x.es.length+(x.es.length===1?' esercizio':' esercizi')+'</span></div></div>'}).join(''):'<div class="empty">Nessuna scheda. Creane una con +.</div>';
}
function chipsHtml(){
  var names=exNames(suid),q=eq.toLowerCase().trim();
  if(!Object.keys(names).length)return '<span class="status">Crea una scheda con degli esercizi per vederne l’andamento.</span>';
  var h=trend.map(function(k,i){return '<button class="chip sel" style="border-color:'+TCOL[i]+'" data-act="erm" data-ex="'+esc(k)+'"><i class="dot" style="background:'+TCOL[i]+'"></i>'+esc(names[k]||k)+' ×</button>'}).join('');
  var sug=Object.keys(names).filter(function(k){return trend.indexOf(k)<0&&(!q||k.indexOf(q)>-1)}).sort().slice(0,12);
  return h+sug.map(function(k){return '<button class="chip" data-act="eadd" data-ex="'+esc(k)+'">'+esc(names[k])+'</button>'}).join('')+(sug.length||trend.length?'':'<span class="status">Nessun esercizio trovato.</span>');
}
function trendPts(u,k){
  var out=[];
  schedeOf(u).forEach(function(sc){var best=null;sc.es.forEach(function(e){if(ekey(e.n)===k&&e.k!==''&&e.k!=null&&!isNaN(+e.k)){var v=+e.k;if(best===null||v>best)best=v}});if(best!==null)out.push({d:sc.data,t:Date.parse(sc.data),v:best})});
  return out.sort(function(a,b){return a.t-b.t});
}
function sdate(iso){var f=fdate(iso);return f.slice(0,6)+f.slice(8)}
function drawChart(ser){
  var W=600,H=260,L=44,R=16,T=14,B=30,all=[],ts=[];
  ser.forEach(function(s){s.pts.forEach(function(p){all.push(p.v);ts.push(p.t)})});
  if(!all.length)return '<div class="status">Nessun carico registrato per questi esercizi.</div>';
  var vmin=Math.min.apply(null,all),vmax=Math.max.apply(null,all),pad=(vmax-vmin)||vmax||1;
  vmin=Math.max(0,vmin-pad*.15);vmax=vmax+pad*.15;
  var tmin=Math.min.apply(null,ts),tmax=Math.max.apply(null,ts),dt=(tmax-tmin)||1;
  function X(t){return tmax===tmin?L+(W-L-R)/2:L+(t-tmin)/dt*(W-L-R)}
  function Y(v){return T+(1-(v-vmin)/(vmax-vmin))*(H-T-B)}
  var g='',i;
  for(i=0;i<=4;i++){var v=vmin+(vmax-vmin)*i/4,y=Y(v);g+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y+'" y2="'+y+'"/><text x="'+(L-6)+'" y="'+(y+4)+'" text-anchor="end">'+fnum(Math.round(v*10)/10)+'</text>'}
  var dates=[];ser.forEach(function(s){s.pts.forEach(function(p){if(dates.indexOf(p.d)<0)dates.push(p.d)})});dates.sort();
  var pick=dates.length<=5?dates:[0,1,2,3,4].map(function(j){return dates[Math.round(j*(dates.length-1)/4)]});
  pick.forEach(function(d){g+='<text x="'+X(Date.parse(d))+'" y="'+(H-8)+'" text-anchor="middle">'+sdate(d)+'</text>'});
  ser.forEach(function(s){
    if(s.pts.length>1)g+='<polyline style="stroke:'+s.color+'" points="'+s.pts.map(function(p){return X(p.t)+','+Y(p.v)}).join(' ')+'"/>';
    s.pts.forEach(function(p){g+='<circle cx="'+X(p.t)+'" cy="'+Y(p.v)+'" r="4.5" style="fill:'+s.color+'"><title>'+esc(s.name)+' · '+fdate(p.d)+' · '+fnum(p.v)+' kg</title></circle>'});
  });
  return '<svg class="chart" viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Andamento del carico in kg nel tempo">'+g+'</svg>';
}
function drawTrend(){
  var c=document.getElementById('echips'),g=document.getElementById('echart');if(!c||!g)return;
  c.innerHTML=chipsHtml();
  if(!trend.length){g.innerHTML='<div class="status">Seleziona uno o più esercizi (massimo 4) per vedere come cresce il carico nel tempo.</div>';return}
  var names=exNames(suid),ser=trend.map(function(k,i){return {name:names[k]||k,color:TCOL[i],pts:trendPts(suid,k)}});
  g.innerHTML=drawChart(ser)+'<div class="leg">'+ser.map(function(s){
    var a=s.pts[0],b=s.pts[s.pts.length-1],t;
    if(!a)t='nessun carico registrato';
    else if(s.pts.length===1)t=fnum(a.v)+' kg (un solo dato)';
    else{var dl=b.v-a.v,pc=a.v>0?Math.round(dl/a.v*1000)/10:0;t=fnum(a.v)+' → '+fnum(b.v)+' kg ('+(dl>=0?'+':'')+fnum(Math.round(dl*10)/10)+' kg, '+(pc>=0?'+':'')+fnum(pc)+'%)'}
    return '<span><i class="dot" style="background:'+s.color+'"></i><b>'+esc(s.name)+'</b>: '+t+'</span>'}).join('')+'</div>';
}
function exRow(n,s,r,k){return '<div class="exr"><button class="lkb" data-act="lk" aria-label="Superserie con l’esercizio sopra" title="Superserie con l’esercizio sopra">SS</button><input class="ex_n" list="exlist" placeholder="Esercizio" value="'+esc(n||'')+'"><input class="ex_s" type="number" min="0" inputmode="numeric" placeholder="Serie"><input class="ex_r" type="number" min="0" inputmode="numeric" placeholder="Rip."><input class="ex_k" type="number" min="0" step="0.5" inputmode="decimal" placeholder="Kg"><button class="xr" data-act="rmex" aria-label="Rimuovi">×</button></div>'}
function refreshEx(){
  var rows=[].slice.call(document.querySelectorAll('#exs .exr'));
  rows.forEach(function(r,i){
    if(i===0)r.classList.remove('lk');
    r.querySelector('.lkb').disabled=(i===0);
    r.classList.toggle('grp',r.classList.contains('lk')||!!(rows[i+1]&&rows[i+1].classList.contains('lk')));
  });
}
function exLabel(e){return (e.g?'<i class="dc">SS '+String.fromCharCode(64+(+e.g))+'</i> ':'')+esc(e.n)}
function schedaForm(){
  var names=EXLIST.slice();Object.keys(exNames(suid)).forEach(function(k){var n=exNames(suid)[k];if(EXLIST.map(ekey).indexOf(k)<0)names.push(n)});
  modal('<h3>Nuova scheda</h3><label>Nome scheda *<input id="sc_n" type="text" placeholder="es. Forza, mese 1"></label><label>Data<input id="sc_d" type="date" value="'+new Date().toISOString().slice(0,10)+'"></label><label>Note<input id="sc_note" type="text"></label>'+
   '<b style="font-size:14px">Esercizi</b><div class="status">Tocca SS per mettere un esercizio in superserie con quello sopra (puoi collegarne più di due).</div><div id="exs" style="display:flex;flex-direction:column;gap:6px">'+exRow()+exRow()+exRow()+'</div><button class="addx" data-act="addex">+ Aggiungi esercizio</button>'+
   '<datalist id="exlist">'+names.map(function(n){return '<option value="'+esc(n)+'">'}).join('')+'</datalist>'+
   '<div class="status" id="scstat"></div><div class="mrow"><button data-act="mclose">Annulla</button><button class="pri" id="scsave" data-act="smsave">Salva</button></div>');
  document.querySelector('#modal .mbox').classList.add('wide');refreshEx();
}
function num(v){return v===''||v==null||isNaN(+v)?'':+v}
async function saveScheda(){
  var nome=document.getElementById('sc_n').value.trim();
  if(!nome){document.getElementById('sc_n').focus();return}
  var es=[].map.call(document.querySelectorAll('#exs .exr'),function(r){return {n:r.querySelector('.ex_n').value.trim(),s:num(r.querySelector('.ex_s').value),r:num(r.querySelector('.ex_r').value),k:num(r.querySelector('.ex_k').value),lk:r.classList.contains('lk')}}).filter(function(x){return x.n});
  var gn=0;es.forEach(function(x,i){if(x.lk&&i>0){if(!es[i-1].g)es[i-1].g=++gn;x.g=es[i-1].g}});es.forEach(function(x){delete x.lk});
  if(!es.length){st('scstat','Aggiungi almeno un esercizio.');return}
  var o={uid:String(suid),nome:nome,data:document.getElementById('sc_d').value||new Date().toISOString().slice(0,10),note:document.getElementById('sc_note').value.trim(),es:es,ts:Date.now()};
  var b=document.getElementById('scsave');b.disabled=true;b.textContent='Salvataggio…';
  try{ o.id=newId('s'); await Store.put('schede',o); SCH.unshift(o); closeModal();listSchede();drawTrend() }
  catch(e){b.disabled=false;b.textContent='Salva';st('scstat','Salvataggio non riuscito. Riprova.')}
}
function viewScheda(id){
  var sc=findS(id);if(!sc)return;var u=find(sc.uid);
  modal('<h3>'+esc(sc.nome)+'</h3><div class="status">'+(u?esc(u.n+' '+u.c)+' · ':'')+fdate(sc.data)+'</div>'+
   '<table class="stab"><thead><tr><th>Esercizio</th><th>Serie</th><th>Rip.</th><th>Kg</th></tr></thead><tbody>'+sc.es.map(function(e){return '<tr><td>'+exLabel(e)+'</td><td>'+esc(e.s)+'</td><td>'+esc(e.r)+'</td><td>'+esc(fnum(e.k))+'</td></tr>'}).join('')+'</tbody></table>'+(sc.note?'<p class="status">'+esc(sc.note)+'</p>':'')+
   '<div class="status" id="sdstat"></div><div class="mrow"><button data-act="mclose">Chiudi</button><button class="pri" data-act="sdl" data-id="'+esc(sc.id)+'">Scarica</button></div>');
}
function schedaHtml(u,sc){
  return '<!doctype html><html lang="it"><head><meta charset="utf-8"><title>'+esc(sc.nome)+'</title><style>body{font-family:system-ui,sans-serif;max-width:720px;margin:32px auto;padding:0 16px;color:#12302b}h1{margin:4px 0}table{border-collapse:collapse;width:100%;margin-top:16px}th,td{border:1px solid #cfdcd9;padding:8px 10px;text-align:left}th{background:#eaf4f2}.m{color:#5d7872;margin:0}.dc{font-style:normal;font-size:11px;font-weight:600;color:#0f766e;background:#d9f0ec;border-radius:99px;padding:1px 8px;margin-right:4px}</style></head><body><p class="m">Speaking</p><h1>'+esc(sc.nome)+'</h1><p class="m">'+esc(u?u.n+' '+u.c:'')+' · '+fdate(sc.data)+'</p><table><thead><tr><th>Esercizio</th><th>Serie</th><th>Ripetizioni</th><th>Carico (kg)</th></tr></thead><tbody>'+
   sc.es.map(function(e){return '<tr><td>'+exLabel(e)+'</td><td>'+esc(e.s)+'</td><td>'+esc(e.r)+'</td><td>'+esc(fnum(e.k))+'</td></tr>'}).join('')+'</tbody></table>'+(sc.note?'<p>'+esc(sc.note)+'</p>':'')+'</body></html>';
}
async function saveBlob(blob,name){
  try{
    if(caps.down){await caps.down.save({filename:name,data:blob})}
    else{var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove()}
  }catch(e){if(!(e&&e.code==='declined'))throw e}
}
async function dlScheda(id){
  var sc=findS(id);if(!sc)return;var u=find(sc.uid);
  try{await saveBlob(new Blob([schedaHtml(u,sc)],{type:'text/html'}),('Scheda_'+(u?u.c+'_'+u.n:'')+'_'+sc.data+'.html').replace(/[^\w.\-]+/g,'_'))}
  catch(e){st('sdstat','Download non riuscito. Riprova.')}
}
async function doDelSchede(){
  var ids=Object.keys(ssel);
  for(var i=0;i<ids.length;i++){try{await Store.del('schede',ids[i])}catch(e){}}
  SCH=SCH.filter(function(x){return !ssel[x.id]});
  ssel={};sdm=false;closeModal();listSchede();drawTrend();
}
async function dropSchedeOf(id){
  var L=schedeOf(id);
  for(var i=0;i<L.length;i++){try{await Store.del('schede',L[i].id)}catch(e){}}
  SCH=SCH.filter(function(x){return String(x.uid)!==String(id)});
}
function refreshSchede(){
  if(cur!=='schede')return;
  if(document.getElementById('slist')){if(!find(suid)){suid=null;renderSchede()}else{listSchede();drawTrend()}}
  else if(document.getElementById('sulist'))listSU();
}
document.addEventListener('input',function(e){var t=e.target;
  if(t.id==='ssearch'){sq=t.value;listSU()}
  else if(t.id==='esearch'){eq=t.value;var c=document.getElementById('echips');if(c)c.innerHTML=chipsHtml()}
});
document.addEventListener('click',function(e){
  var a=e.target.closest('[data-act]');
  if(a){var k=a.getAttribute('data-act'),ex=a.getAttribute('data-ex');
    if(k==='sback'){suid=null;sdm=false;ssel={};trend=[];eq='';renderSchede()}
    else if(k==='sadd')schedaForm();
    else if(k==='addex'){document.getElementById('exs').insertAdjacentHTML('beforeend',exRow());refreshEx()}
    else if(k==='lk'){var rw=a.closest('.exr');if(rw){rw.classList.toggle('lk');refreshEx()}}
    else if(k==='rmex'){var r=a.closest('.exr');if(r&&document.querySelectorAll('#exs .exr').length>1){r.remove();refreshEx()}}
    else if(k==='smsave')saveScheda();
    else if(k==='sdel'){sdm=!sdm;ssel={};listSchede()}
    else if(k==='scancel'){sdm=false;ssel={};listSchede()}
    else if(k==='sconfirm'){var n=Object.keys(ssel).length;if(!n)return;modal('<h3>Elimina schede</h3><p>Vuoi eliminare '+n+(n===1?' scheda selezionata':' schede selezionate')+'? L’operazione non si può annullare.</p><div class="mrow"><button data-act="mclose">Annulla</button><button class="danger" data-act="sdodel">Elimina</button></div>')}
    else if(k==='sdodel')doDelSchede();
    else if(k==='sdl')dlScheda(a.getAttribute('data-id'));
    else if(k==='eadd'){if(trend.length<4){trend.push(ex);drawTrend()}}
    else if(k==='erm'){trend=trend.filter(function(x){return x!==ex});drawTrend()}
    return}
  var su=e.target.closest('[data-su]');
  if(su){suid=su.getAttribute('data-su');sdm=false;ssel={};trend=[];eq='';renderSchede();return}
  var sr=e.target.closest('[data-srow]');
  if(sr){var id=sr.getAttribute('data-srow');if(sdm){if(ssel[id])delete ssel[id];else ssel[id]=1;listSchede()}else viewScheda(id)}
});
function autoView(){setView(window.innerWidth>=768?'tablet':'mobile')}
autoView();
window.addEventListener('resize',autoView);
render();
Store.load().then(function(){render()});
